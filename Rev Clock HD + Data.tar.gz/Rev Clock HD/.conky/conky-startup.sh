#!/bin/bash

killall conky

sleep 10 &
conky -c $HOME/.conky/rev_hd/conkyrc &
sleep 1 &
conky -c $HOME/.conky/rev_hd/network &
sleep 1 &
conky -c $HOME/.conky/rev_hd/process -q &

exit 0
