Rev clock HD

It is distinguished from other such clocks by the clock rings not having a fixed starting position but rather move as a function of time and likewise expand circumferentially as a function of time. 

It is configurable and has vast potential if a graphics designer used their imagination. I have quickly uploaded it to demonstrate the scripts potential.

The lua script is explained in the c_c_s_explanation.txt file.

To install just copy the ".conky" folder to your user/home folder!

Don't forget to install the font to ".fonts"!

to run, execute ' conky-startup.sh '

To enable conky to start with the system go to " startup applications " and add in the " command " the file " .conky/conky-startup.sh "
